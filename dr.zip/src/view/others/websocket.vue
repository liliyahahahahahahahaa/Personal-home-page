<template>
    <div class="text-left">

      <h1>vue + websocket连接demo</h1>
        <!-- <Button @click="test">test</Button> -->
        
    </div>
</template>

<script>
export default {
  name: 'workTime',
  props: {
    workDateList:[]
  },
  data() {
      return {
      }
    },
    created(){
    },
    mounted(){
    },
    methods:{
    }
}
</script>


<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="scss" scoped>
 
</style>
